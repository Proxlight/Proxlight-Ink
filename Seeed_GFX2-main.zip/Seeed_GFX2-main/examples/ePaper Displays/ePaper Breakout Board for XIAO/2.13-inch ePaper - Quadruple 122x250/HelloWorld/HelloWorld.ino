/**
 * Panel: 2.13 inch BWRY ePaper (212x104, JD79676) - Black / White / Red / Yellow
 * Board: XIAO ePaper Breakout Board (template API - no registered product for this board).
 */
#include <Seeed_GFX.h>
#include "board/boards/XIAO_ePaper_Boards.h"
#include "panel/configs/Seeed_Panel_Configs.h"
#include "driver/epaper/Driver_JD79676.h"
#include "panel/Panel_EPaper.h"

Seeed_GFX display;

void setup() {
    Serial.begin(115200);
    if (!display.begin<Board_XIAO_ePaper_Breakout, Config_Seeed_ePaper_2inch13_BWRY_JD79676>()) { Serial.println(display.lastResult().message); return; }

    // Landscape glass: rotate the 128x250 portrait framebuffer to 250x128,
    // mirroring the working 2.9" BWRY (which uses setRotation(3)). Without it
    // the text renders rotated 90 degrees on the landscape-mounted glass.
    display.setRotation(3);


    display.fillScreen(TFT_WHITE);

    const int16_t w = display.width();   // 212
    const int16_t h = display.height();  // 104

    display.drawRect(2, 2, w - 4, h - 4, TFT_BLACK);

    display.setTextColor(TFT_BLACK);
    display.setTextSize(2);
    display.drawString("2.13 BWRY", 6, 4);
    display.setTextSize(1);
    display.drawRightString("Breakout / 4-color", w - 6, 8, 1);

    display.drawLine(6, 26, w - 6, 26, TFT_BLACK);

    const int16_t sw = 45, sh = 44, gap = 6;
    const int16_t sy = 32;
    const uint16_t colors[4] = { TFT_BLACK, TFT_WHITE, TFT_RED, TFT_YELLOW };
    for (uint8_t i = 0; i < 4; i++) {
        int16_t sx = 6 + i * (sw + gap);
        display.fillRect(sx, sy, sw, sh, colors[i]);
        display.drawRect(sx, sy, sw, sh, TFT_BLACK);
    }

    display.fillRect(6, h - 18, w - 12, 14, TFT_BLACK);
    display.setTextColor(TFT_YELLOW);
    display.setTextSize(1);
    display.drawCentreString("Hello World", w / 2, h - 16, 1);

    display.update();
}

void loop() {}
