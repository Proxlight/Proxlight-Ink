/*
 * reTerminal E1003 -- SD card image to 16-level grayscale e-paper (1872x1404, ED103TC2).
 *
 * Pipeline mirrors online_img2bitmap_.html with screen=gray16:
 *   SD JPG/BMP/PNG -> RGB888 -> luma + gamma + Floyd-Steinberg gray16 dither
 *               -> packed 4bpp -> pushImage4BPP into the Gray16 frame buffer.
 *
 * MEMORY BUDGET (1872x1404 panel + XIAO ESP32-S3 8 MB PSRAM):
 *   - Gray16 frame buffer: 1872*1404 / 2 = 1.32 MB
 *   - Source RGB888 decode: width*height*3 bytes
 *   - Direct 4bpp output:   ceil(width/2)*height bytes
 *
 * Direct packed output saves half a byte per pixel versus the former temporary index
 * buffer. The recommended workflow for inputs that still exceed PSRAM is
 * to pre-resize / dither the image in online_img2bitmap_.html, then export a BMP at
 * panel resolution. Large unscaled BMP files use the row-streaming decoder and avoid
 * allocating a full RGB888 image plus a second quantization buffer.
 *
 * Hardware: reTerminal E1003 (XIAO ESP32-S3 + 10.3" ED103TC2 16-level gray e-paper).
 *
 *           Function     ESP32-S3 GPIO
 *           SPI SCK      7   (shared with SD)
 *           SPI MISO     8   (shared with SD)
 *           SPI MOSI     9   (shared with SD)
 *           EPD CS       10
 *           EPD ENABLE   11
 *           EPD RST      12
 *           EPD BUSY     13
 *           ITE ENABLE   21
 *           SD  CS       14
 *           SD  EN       39   (NOTE: differs from E1001/E1002/E1004 which use GPIO16)
 *           SD  DET      15
 *
 * Logging goes out on UART1 (GPIO43 TX, GPIO44 RX) -- the on-board USB-to-UART
 * bridge of the reTerminal carrier board is wired there. The default Arduino
 * `Serial` (USB CDC) only works when "USB CDC On Boot" is enabled, which is
 * unreliable for diagnostics on reTerminal.
 */

#include <SPI.h>
#include <FS.h>
#include <SD.h>
#include <Seeed_GFX.h>
#include "bus/Bus_SPI.h"

#include <dither/Dither.h>
#include "image_loader.h"

Seeed_GFX display(Seeed_Product::reTerminal_E1003);
static DitherContext ditherContext;
static constexpr int EPD_WIDTH  = 1872;
static constexpr int EPD_HEIGHT = 1404;

// ----- pins ------------------------------------------------------------------
// SD pins are identical across all reTerminal E10xx carrier boards, except
// SD_EN: E1001/E1002/E1004 use GPIO16, E1003 uses GPIO39.
static constexpr int    PIN_SD_SCK   = 7;   // shared with e-paper SPI bus
static constexpr int    PIN_SD_MISO  = 8;
static constexpr int    PIN_SD_MOSI  = 9;   // shared with e-paper SPI bus
static constexpr int    PIN_SD_CS    = 14;
static constexpr int    PIN_SD_EN    = 39;   // E1003 only -- other reTerminal models use GPIO16
static constexpr int    PIN_SD_DET   = 15;
static constexpr int    PIN_DBG_RX   = 44;
static constexpr int    PIN_DBG_TX   = 43;
#define LOG       Serial1
#define TAG       "[e1003]"

// USER CONFIGURATION -- edit the constants below. Each option lists all the
// values you can pick from right above it.

// ----- image source ----------------------------------------------------------
// Path to the image on the SD card (must start with '/').
// Supported formats:
//   .jpg / .jpeg -- baseline JFIF (8-bit, YCbCr or grayscale)
//   .bmp         -- 24-bit BGR uncompressed, or 4-bit indexed (BI_RGB)
//   .png         -- common PNG color types (decoded via bundled pngle;
//                    RGBA images are alpha-composited over white).
// The actual format is sniffed from magic bytes -- a misleading extension is
// auto-corrected and a warning is printed.
static const char* IMAGE_PATH = "/img/demo.jpg";

// ----- dither ----------------------------------------------------------------
// Dithering algorithm. Same options as online_img2bitmap_.html. Pick one:
//   DITHER_NONE     -- nearest-color, no dithering (fastest, blocky)
//   DITHER_BAYER8   -- 8x8 ordered Bayer (no error buffer; safest on big panels)
//   DITHER_FS       -- Floyd-Steinberg (best quality/speed balance, default)
//   DITHER_ATKINSON -- Atkinson (high contrast, classic Mac look)
//   DITHER_BURKES   -- Burkes (smooth, two-row error buffer)
//   DITHER_SIERRA3  -- Full Sierra (smoothest, three-row error buffer)
// DITHER_PALETTE_MIX is only available for E6/BWRY color palettes.
static const DitherMethod DITHER_METHOD = DITHER_FS;

// Brightness gamma. 1.0 = neutral, >1.0 brightens, <1.0 darkens. Typical 0.8 - 1.6.
static const float DITHER_GAMMA = 1.0f;

// ----- layout: position -----------------------------------------------------
// Where on the panel the image snaps to. Pick one of these 9 anchors in a
// 3x3 grid:
//   ANCHOR_TOP_LEFT       ANCHOR_TOP_CENTER       ANCHOR_TOP_RIGHT
//   ANCHOR_MIDDLE_LEFT    ANCHOR_CENTER           ANCHOR_MIDDLE_RIGHT
//   ANCHOR_BOTTOM_LEFT    ANCHOR_BOTTOM_CENTER    ANCHOR_BOTTOM_RIGHT
enum DisplayAnchor {
  ANCHOR_TOP_LEFT,      ANCHOR_TOP_CENTER,      ANCHOR_TOP_RIGHT,
  ANCHOR_MIDDLE_LEFT,   ANCHOR_CENTER,          ANCHOR_MIDDLE_RIGHT,
  ANCHOR_BOTTOM_LEFT,   ANCHOR_BOTTOM_CENTER,   ANCHOR_BOTTOM_RIGHT,
};
static const DisplayAnchor DISPLAY_ANCHOR = ANCHOR_CENTER;

// ----- layout: size ---------------------------------------------------------
// How the image is sized relative to the panel. Pick one:
//   FIT_ORIGINAL -- keep source size as-is (no resize; check PSRAM budget)
//   FIT_CONTAIN  -- shrink to fit fully inside the panel; NEVER upscales
//                   (behaves like FIT_ORIGINAL if source is already smaller)
//   FIT_SCALE    -- multiply source size by DISPLAY_SCALE below
enum DisplayFit { FIT_ORIGINAL, FIT_CONTAIN, FIT_SCALE };
static const DisplayFit DISPLAY_FIT = FIT_ORIGINAL;

// Scale factor -- only used when DISPLAY_FIT == FIT_SCALE. Examples:
//   0.25 -- quarter size       0.5  -- half size
//   1.0  -- original            2.0  -- 2x zoom (>1.0 may OOM on this panel)
static const float DISPLAY_SCALE = 1.0f;

// ----- diagnostics helpers ----------------------------------------------------
static void log_mem(const char* tag) {
  LOG.printf("[mem] %-22s heap=%lu kB  PSRAM free=%lu/%lu kB\n", tag,
             (unsigned long)(ESP.getFreeHeap() / 1024),
             (unsigned long)(ESP.getFreePsram() / 1024),
             (unsigned long)(ESP.getPsramSize() / 1024));
  LOG.flush();
}

static void list_sd_root(int max_entries = 32) {
  File root = SD.open("/");
  if (!root || !root.isDirectory()) {
    LOG.println("[sd] cannot open '/' on the card");
    if (root) root.close();
    return;
  }
  LOG.println("[sd] contents of '/' :");
  int n = 0;
  File entry = root.openNextFile();
  while (entry) {
    if (entry.isDirectory()) LOG.printf("   <DIR>  %s\n", entry.name());
    else                     LOG.printf("   %7lu B  %s\n",
                                        (unsigned long)entry.size(), entry.name());
    entry.close();
    if (++n >= max_entries) { LOG.printf("   ... (truncated at %d entries)\n", max_entries); break; }
    entry = root.openNextFile();
  }
  if (n == 0) LOG.println("   (empty)");
  root.close();
  LOG.flush();
}

static bool is_supported_image_name(const String& name) {
  const int dot = name.lastIndexOf('.');
  if (dot < 0) return false;
  String ext = name.substring(dot);
  ext.toLowerCase();
  return ext == ".jpg" || ext == ".jpeg" || ext == ".bmp" || ext == ".png";
}

static String first_image_in(const char* directory) {
  File dir = SD.open(directory);
  if (!dir || !dir.isDirectory()) {
    if (dir) dir.close();
    return String();
  }

  String result;
  File entry = dir.openNextFile();
  while (entry) {
    if (!entry.isDirectory()) {
      String name(entry.name());
      if (is_supported_image_name(name)) {
        if (name.startsWith("/")) result = name;
        else if (name.indexOf('/') >= 0) result = String("/") + name;
        else {
          result = String(directory);
          if (!result.endsWith("/")) result += '/';
          result += name;
        }
        entry.close();
        break;
      }
    }
    entry.close();
    entry = dir.openNextFile();
  }
  dir.close();
  return result;
}

static String choose_image_path() {
  if (SD.exists(IMAGE_PATH)) return String(IMAGE_PATH);
  String fallback = first_image_in("/img");
  if (fallback.length() == 0) fallback = first_image_in("/");
  if (fallback.length()) {
    LOG.printf("[sd] '%s' not found; using first supported image '%s'\n",
               IMAGE_PATH, fallback.c_str());
  }
  return fallback;
}

// ----- layout helpers ---------------------------------------------------------
static void compute_target_size(int src_w, int src_h, DisplayFit fit, float scale,
                                int panel_w, int panel_h,
                                int* out_w, int* out_h) {
  switch (fit) {
    case FIT_ORIGINAL:
      *out_w = src_w; *out_h = src_h;
      break;
    case FIT_CONTAIN: {
      double sx = (double)panel_w / src_w;
      double sy = (double)panel_h / src_h;
      double s  = (sx < sy) ? sx : sy;
      if (s > 1.0) s = 1.0;
      *out_w = (int)(src_w * s + 0.5);
      *out_h = (int)(src_h * s + 0.5);
      break;
    }
    case FIT_SCALE:
      *out_w = (int)(src_w * scale + 0.5);
      *out_h = (int)(src_h * scale + 0.5);
      break;
  }
  if (*out_w < 1) *out_w = 1;
  if (*out_h < 1) *out_h = 1;
}

static void compute_anchor_xy(int img_w, int img_h, DisplayAnchor a,
                              int panel_w, int panel_h,
                              int* out_x, int* out_y) {
  int x = 0, y = 0;
  switch (a) {
    case ANCHOR_TOP_LEFT:      x = 0;                      y = 0;                       break;
    case ANCHOR_TOP_CENTER:    x = (panel_w - img_w) / 2;  y = 0;                       break;
    case ANCHOR_TOP_RIGHT:     x = panel_w - img_w;        y = 0;                       break;
    case ANCHOR_MIDDLE_LEFT:   x = 0;                      y = (panel_h - img_h) / 2;   break;
    case ANCHOR_CENTER:        x = (panel_w - img_w) / 2;  y = (panel_h - img_h) / 2;   break;
    case ANCHOR_MIDDLE_RIGHT:  x = panel_w - img_w;        y = (panel_h - img_h) / 2;   break;
    case ANCHOR_BOTTOM_LEFT:   x = 0;                      y = panel_h - img_h;         break;
    case ANCHOR_BOTTOM_CENTER: x = (panel_w - img_w) / 2;  y = panel_h - img_h;         break;
    case ANCHOR_BOTTOM_RIGHT:  x = panel_w - img_w;        y = panel_h - img_h;         break;
  }
  *out_x = x; *out_y = y;
}

static const char* fit_name(DisplayFit f) {
  switch (f) {
    case FIT_ORIGINAL: return "ORIGINAL";
    case FIT_CONTAIN:  return "CONTAIN";
    case FIT_SCALE:    return "SCALE";
  }
  return "?";
}
static const char* anchor_name(DisplayAnchor a) {
  switch (a) {
    case ANCHOR_TOP_LEFT:      return "TOP_LEFT";
    case ANCHOR_TOP_CENTER:    return "TOP_CENTER";
    case ANCHOR_TOP_RIGHT:     return "TOP_RIGHT";
    case ANCHOR_MIDDLE_LEFT:   return "MIDDLE_LEFT";
    case ANCHOR_CENTER:        return "CENTER";
    case ANCHOR_MIDDLE_RIGHT:  return "MIDDLE_RIGHT";
    case ANCHOR_BOTTOM_LEFT:   return "BOTTOM_LEFT";
    case ANCHOR_BOTTOM_CENTER: return "BOTTOM_CENTER";
    case ANCHOR_BOTTOM_RIGHT:  return "BOTTOM_RIGHT";
  }
  return "?";
}

enum StreamBmpResult {
  STREAM_BMP_NOT_NEEDED = 0,
  STREAM_BMP_OK = 1,
  STREAM_BMP_FAILED = -1
};

static uint32_t read_le32(const uint8_t* p) {
  return (uint32_t)p[0] | ((uint32_t)p[1] << 8) |
         ((uint32_t)p[2] << 16) | ((uint32_t)p[3] << 24);
}

static size_t sd_file_read_at(void* context, uint32_t offset,
                              void* destination, size_t length) {
  File* file = static_cast<File*>(context);
  if (!file || !*file || !file->seek(offset)) return 0;
  return file->read(static_cast<uint8_t*>(destination), length);
}

// A full-panel buffered RGB888 decode can still approach the PSRAM limit once
// display/output/scratch storage is included. For an unscaled BMP, use
// Seeed_GFX2's row decoder so only one source row is buffered. JPEG/PNG still
// use the dither pipeline below. The threshold remains intentionally
// conservative and includes memory reserved for decoder/display overhead.
static StreamBmpResult stream_large_bmp_if_needed(const char* path) {
  File file = SD.open(path, FILE_READ);
  if (!file) return STREAM_BMP_FAILED;

  uint8_t header[26];
  if (file.read(header, sizeof(header)) != sizeof(header) ||
      header[0] != 'B' || header[1] != 'M') {
    file.close();
    return STREAM_BMP_NOT_NEEDED;
  }

  const int32_t sourceW = (int32_t)read_le32(header + 18);
  const int32_t signedH = (int32_t)read_le32(header + 22);
  if (sourceW <= 0 || signedH == 0 || signedH == INT32_MIN) {
    LOG.println("[bmp] invalid dimensions");
    file.close();
    return STREAM_BMP_FAILED;
  }
  const int32_t sourceH = signedH < 0 ? -signedH : signedH;
  const uint64_t bufferedNeed = (uint64_t)sourceW * sourceH * 4ULL;
  const uint64_t freePsram = ESP.getFreePsram();
  const uint64_t reserve = 128ULL * 1024ULL;
  if (bufferedNeed + reserve <= freePsram) {
    file.close();
    return STREAM_BMP_NOT_NEEDED;
  }

  int targetW, targetH;
  compute_target_size(sourceW, sourceH, DISPLAY_FIT, DISPLAY_SCALE,
                      EPD_WIDTH, EPD_HEIGHT, &targetW, &targetH);
  if (targetW != sourceW || targetH != sourceH) {
    LOG.printf("[bmp] buffered resize needs about %llu kB, but streaming cannot scale\n",
               (unsigned long long)(bufferedNeed / 1024ULL));
    LOG.println("[bmp] pre-resize the BMP on a PC or select FIT_ORIGINAL");
    file.close();
    return STREAM_BMP_FAILED;
  }

  int x, y;
  compute_anchor_xy(sourceW, sourceH, DISPLAY_ANCHOR,
                    EPD_WIDTH, EPD_HEIGHT, &x, &y);
  LOG.printf("[bmp] large %ldx%ld image: streaming rows at (%d,%d)\n",
             (long)sourceW, (long)sourceH, x, y);
  UiCallbackSource source((uint32_t)file.size(), sd_file_read_at, &file);
  const UiStatus status = display.drawImage(x, y, source, UiImageFormat::BMP);
  file.close();
  if (!uiOk(status)) {
    LOG.printf("[bmp] stream decode failed (UiStatus=%u)\n", (unsigned)status);
    return STREAM_BMP_FAILED;
  }

  LOG.println(TAG " update() -- panel refresh starts");
  LOG.flush();
  const GfxResult refreshResult = display.refresh();
  if (!refreshResult) {
    LOG.printf(TAG " refresh failed: %s\n", refreshResult.message);
    return STREAM_BMP_FAILED;
  }
  return STREAM_BMP_OK;
}

// ----- main pipeline ----------------------------------------------------------
static bool show_image_on_panel(RgbImage* img) {
  // Force full-screen: always resize to panel dimensions.
  int W = EPD_WIDTH;
  int H = EPD_HEIGHT;
  int x = 0, y = 0;
  LOG.printf("[layout] src=%dx%d -> fullscreen %dx%d\n",
             img->width, img->height, W, H);

  // 2) Resize if needed. resize_image() allocates a new PSRAM buffer for the
  //    target and then frees the old one, so peak memory briefly holds both.
  if (W != img->width || H != img->height) {
    const size_t need_kb = (size_t)W * H * 3 / 1024;
    LOG.printf("[layout] resizing %dx%d -> %dx%d  (needs +%lu kB temporarily)\n",
               img->width, img->height, W, H, (unsigned long)need_kb);
    log_mem("before resize");
    if (!resize_image(img, W, H)) {
      LOG.println("[layout] resize failed (likely OOM) -- aborting");
      LOG.println("[layout]   try FIT_ORIGINAL, or a smaller DISPLAY_SCALE,");
      LOG.println("[layout]   or pre-shrink the image on the PC");
      return false;
    }
    log_mem("after resize");
  }

  const size_t indexBytes = (size_t)W * H;
  const size_t packedBytes = ((size_t)W + 1u) / 2u * H;

  // 3) Dither directly into the panel's packed Gray16 format.
  log_mem("before output malloc");
  LOG.printf(TAG " allocating packed output: %lu kB (saves %lu kB)\n",
             (unsigned long)(packedBytes / 1024),
             (unsigned long)((indexBytes - packedBytes) / 1024));
  uint8_t* packed = (uint8_t*)ps_malloc(packedBytes);
  if (!packed) packed = (uint8_t*)malloc(packedBytes);
  if (!packed) { LOG.println(TAG " OOM packed output -- aborting"); return false; }

  LOG.printf(TAG " dithering Gray16 with %s, gamma=%.2f ...\n",
             dither_method_name(DITHER_METHOD), DITHER_GAMMA);
  DitherConfig cfg;
  cfg.palette = PAL_GRAY16;
  cfg.method = DITHER_METHOD;
  cfg.gamma = DITHER_GAMMA;
  cfg.serpentine = true;
  const uint32_t t0 = millis();
  if (!dither_image_4bpp(img->pixels, W, H, cfg, ditherContext,
                         packed, 0x0F)) {
    LOG.println(TAG " dither failed -- aborting");
    free(packed);
    return false;
  }
  LOG.printf(TAG " dither done in %lu ms\n", (unsigned long)(millis() - t0));
  LOG.printf(TAG " dither work=%lu B context=%lu B output=%lu B\n",
             (unsigned long)dither_working_memory_bytes(W, PAL_GRAY16,
                                                        DITHER_METHOD),
             (unsigned long)ditherContext.workingMemoryCapacity(),
             (unsigned long)packedBytes);

  // 4) Free the RGB888 source; the dither output is already packed 4bpp.
  LOG.println(TAG " freeing RGB888 source");
  image_free(img);
  log_mem("after RGB888 freed");

  // 5) Preserve the packed Gray16 nibbles; this is not RGB565.
  LOG.printf(TAG " pushImage4BPP %dx%d at (%d,%d) -> framebuffer\n",
             W, H, x, y);
  if (!display.pushImage4BPP(x, y, W, H, packed)) {
    LOG.println(TAG " packed 4bpp image rejected");
    free(packed);
    return false;
  }
  LOG.println(TAG " update() -- panel refresh starts (~1-3s on Gray16)");
  LOG.flush();
  const uint32_t t1 = millis();
  const GfxResult refreshResult = display.refresh();
  LOG.printf(TAG " update done in %lu ms\n", (unsigned long)(millis() - t1));
  free(packed);
  if (!refreshResult) {
    LOG.printf(TAG " refresh failed: %s\n", refreshResult.message);
    return false;
  }
  return true;
}

void setup() {
  LOG.begin(115200, SERIAL_8N1, PIN_DBG_RX, PIN_DBG_TX);
  delay(2500);
  LOG.println();
  LOG.println("==============================================");
  LOG.println("  reTerminal E1003 -- SD Bitmap (Gray16)");
  LOG.println("==============================================");
  LOG.printf("[sys] chip      : ESP32-S3 @ %lu MHz\n", (unsigned long)ESP.getCpuFreqMHz());
  LOG.printf("[sys] PSRAM size: %lu kB\n", (unsigned long)(ESP.getPsramSize() / 1024));
  if (ESP.getPsramSize() == 0) {
    LOG.println("[sys] !!! PSRAM is 0 kB -- enable Tools > PSRAM > OPI PSRAM in the IDE !!!");
  }
  LOG.printf("[sys] panel     : %d x %d (EPD_WIDTH x EPD_HEIGHT)\n", EPD_WIDTH, EPD_HEIGHT);
  LOG.printf("[sys] image     : '%s'\n", IMAGE_PATH);
  LOG.flush();

  pinMode(PIN_SD_EN, OUTPUT);
  digitalWrite(PIN_SD_EN, HIGH);
  pinMode(PIN_SD_DET, INPUT_PULLUP);
  delay(50);
  const int sd_det = digitalRead(PIN_SD_DET);
  LOG.printf("[sd] SD_DET (GPIO%d) reads %s -- %s\n", PIN_SD_DET,
             sd_det ? "HIGH" : "LOW",
             sd_det ? "no card detected (or DET pin floating)" : "card present");
  LOG.flush();

  LOG.println(TAG " display.begin() ...");
  if (!display.begin()) {
    LOG.printf(TAG " display.begin failed: %s\n", display.lastResult().message);
    return;
  }

  // A Gray16 framebuffer initialized to index 15 is only controller memory;
  // it does not physically erase the image retained by the ePaper glass.
  // Clear only the new framebuffer here.  A physical pre-clear would add a
  // second full refresh and a long white interval before the actual picture.
  display.fillScreen(TFT_WHITE);

  const GfxResult modeResult = display.panel().configure(PanelMode::Gray16);
  if (!modeResult) {
    LOG.printf(TAG " Gray16 configuration failed: %s\n", modeResult.message);
    return;
  }
  // configure(Gray16) now allocates a fresh packed buffer initialized to
  // index 15 (white); the physical pre-clear above has already removed the
  // previous sketch's retained image.
  log_mem("after Gray16 configure");

  Bus_SPI& displayBus =
      static_cast<Bus_SPI&>(display.panel().driver().bus());
  SPIClass* spi = displayBus.spiInstance();
  if (!spi) {
    LOG.println(TAG " shared SPI instance unavailable -- aborting");
    return;
  }

  LOG.println(TAG " SD.begin (shares HSPI with ePaper) ...");
  if (!SD.begin(PIN_SD_CS, *spi)) {
    LOG.println(TAG " SD.begin FAILED -- aborting");
    LOG.println(TAG "   - Is the card inserted and formatted as FAT/FAT32?");
    LOG.printf (TAG "   - Is SD_EN (GPIO%d) actually wired to power the slot?\n", PIN_SD_EN);
    return;
  }
  LOG.printf("[sd] mounted; card size = %llu MB\n",
             (unsigned long long)(SD.cardSize() / (1024ULL * 1024ULL)));
  list_sd_root();

  const String imagePath = choose_image_path();
  if (imagePath.length() == 0) {
    LOG.printf(TAG " no supported image found (configured path: '%s')\n", IMAGE_PATH);
    LOG.println(TAG "   - copy a JPG, BMP, or PNG to '/img' or the card root");
    LOG.println(TAG "   - paths and file names are case-sensitive");
    return;
  }
  {
    File probe = SD.open(imagePath.c_str(), FILE_READ);
    if (probe) {
      LOG.printf(TAG " image found: %s (%lu bytes)\n",
                 imagePath.c_str(), (unsigned long)probe.size());
      probe.close();
    }
  }

  const StreamBmpResult streamed = stream_large_bmp_if_needed(imagePath.c_str());
  if (streamed == STREAM_BMP_OK) {
    LOG.println(TAG " large BMP streamed and displayed OK");
    return;
  }
  if (streamed == STREAM_BMP_FAILED) {
    LOG.println(TAG " large BMP streaming failed -- aborting");
    return;
  }

  log_mem("before image load");
  RgbImage img;
  if (!load_image_from_sd(imagePath.c_str(), /*target_w=*/0, /*target_h=*/0, &img)) {
    LOG.println(TAG " load failed -- aborting");
    LOG.println(TAG "   common issues:");
    LOG.println(TAG "    - source resolution too large (decodes to > 8 MB RGB888)");
    LOG.println(TAG "    - JPEG: non-baseline (progressive / 4:1:1 / CMYK not supported)");
    LOG.println(TAG "    - PNG : source must fit RGB888 memory before layout scaling");
    return;
  }
  LOG.printf(TAG " image decoded: %dx%d  (%lu kB in PSRAM)\n",
             img.width, img.height,
             (unsigned long)((size_t)img.width * img.height * 3 / 1024));
  log_mem("after image decoded");

  if (show_image_on_panel(&img)) LOG.println(TAG " frame pushed OK");
  else                           LOG.println(TAG " show_image_on_panel failed");
  image_free(&img);

  LOG.println(TAG " done. Panel is asleep after refresh.");
  LOG.println("==============================================");
}

void loop() {
  // The e-paper holds the image without power. Press RESET to re-display.
  delay(1000);
}
