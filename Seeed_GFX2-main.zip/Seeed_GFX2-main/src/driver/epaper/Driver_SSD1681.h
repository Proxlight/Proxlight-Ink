/**
 * @file   Driver_SSD1681.h
 * @brief  SSD1681 ePaper display driver for Seeed_GFX v2.0
 *
 * 200x200 1-bit ePaper driver with partial and 4-level grayscale support.
 */

#ifndef SEEED_GFX_DRIVER_SSD1681_H
#define SEEED_GFX_DRIVER_SSD1681_H

#include <Arduino.h>
#include "../../core/Driver.h"

class Driver_SSD1681 : public IDriver {
public:
    Driver_SSD1681(uint16_t w = 200, uint16_t h = 200, int8_t busyPin = -1);

    const char* name() const override { return "SSD1681"; }
    uint16_t width() const override { return _width; }
    uint16_t height() const override { return _height; }
    uint16_t nativeWidth() const override { return _init_width; }
    uint16_t nativeHeight() const override { return _init_height; }
    uint8_t colorDepth() const override { return 1; }
    bool supportsDeepSleep() const override { return true; }

    bool init(IBus& bus) override;
    void setRotation(uint8_t rotation) override;
    uint8_t rotation() const override { return _rotation; }
    void invertDisplay(bool invert) override;
    void displayOn() override;
    void displayOff() override;
    void setAddrWindow(uint16_t xs, uint16_t ys, uint16_t xe, uint16_t ye) override;
    void writePixel(uint16_t color) override;
    void writePixels(const uint16_t* data, size_t len) override;
    void writeFill(uint16_t color, size_t len) override;
    void sleep() override;
    void wake() override;
    IBus& bus() override { return *_bus; }

    // ePaper-specific
    bool supportsPartialRefresh() const override { return true; }
    bool supportsFastRefresh() const override { return true; }
    bool supportsGrayRefresh(uint8_t levels) const override { return levels == 4; }
    void setBusyPin(int pin) override { _busyPin = static_cast<int8_t>(pin); }
    void update() override;
    void updateFast() override;
    void updateGray() override;
    void updatePartial() override;
    void initGray();
    void initPartial();
    void wakeGray() override;
    void wakePartial() override;
    void pushColors(const uint8_t* data, uint16_t w, uint16_t h);
    void pushNewColors(const uint8_t* data, size_t len) override {
        if (!_bus || !data) return;
        _bus->writeCommand(0x24); _bus->writeData(data, len);
    }
    void pushOldColors(const uint8_t* data, size_t len) override {
        if (!_bus || !data) return;
        _bus->writeCommand(0x26); _bus->writeData(data, len);
    }
    void pushColorsFlip(const uint8_t* data, uint16_t w, uint16_t h);
    void pushOldColors(const uint8_t* data, uint16_t w, uint16_t h);
    void pushOldColorsFlip(const uint8_t* data, uint16_t w, uint16_t h);
    void pushGrayColors(const uint8_t* data, uint16_t w, uint16_t h);
    void pushGrayColors(const uint8_t* data, size_t len) override {
        (void)len;
        pushGrayColors(data, _init_width, _init_height);
    }
    void pushGrayColorsFlip(const uint8_t* data, uint16_t w, uint16_t h);
    void setTemp(uint8_t temp) { (void)temp; }
    void setTemperature(int8_t temp) override { setTemp(static_cast<uint8_t>(temp)); }

private:
    void busyWait();
    uint16_t _init_width, _init_height;
    int8_t _busyPin;
};

#endif // SEEED_GFX_DRIVER_SSD1681_H
