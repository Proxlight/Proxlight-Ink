/**
 * @file   Driver_ED2208.h
 * @brief  ED2208 ePaper display driver for Seeed_GFX v2.0
 *
 * 4-bit six-color ePaper driver used by Seeed 400x600 and 800x480 panels.
 */

#ifndef SEEED_GFX_DRIVER_ED2208_H
#define SEEED_GFX_DRIVER_ED2208_H

#include <Arduino.h>
#include "../../core/Driver.h"
#include "../../core/Gpio.h"

class Driver_ED2208 : public IDriver {
public:
    Driver_ED2208(uint16_t w = 800, uint16_t h = 480, int8_t busyPin = -1);

    const char* name() const override { return "ED2208"; }
    uint16_t width() const override { return _width; }
    uint16_t height() const override { return _height; }
    uint8_t colorDepth() const override { return 4; }
    bool supportsColorfulEPaper() const override { return true; }
    bool supportsDeepSleep() const override { return true; }

    bool init(IBus& bus) override;
    void setRotation(uint8_t rotation) override;
    uint8_t rotation() const override { return _rotation; }
    void invertDisplay(bool invert) override;
    void displayOn() override;
    void displayOff() override;
    void setAddrWindow(uint16_t xs, uint16_t ys, uint16_t xe, uint16_t ye) override;
    void writePixel(uint16_t color) override;
    void writePixels(const uint16_t* data, size_t len) override;
    void writeFill(uint16_t color, size_t len) override;
    void sleep() override;
    void wake() override;
    IBus& bus() override { return *_bus; }

    // ePaper-specific
    void update() override;
    void setBusyPin(int pin) override { _busyPin = static_cast<int8_t>(pin); }
    void pushNewColors(const uint8_t* data, size_t len) override;
    void pushOldColors(const uint8_t* data, size_t len) override;
    void pushColors(const uint8_t* data, uint16_t w, uint16_t h);
    void pushColorsFlip(const uint8_t* data, uint16_t w, uint16_t h);
    void setTemp(uint8_t temp) { (void)temp; }
    void setTemperature(int8_t temp) override { setTemp(static_cast<uint8_t>(temp)); }

private:
    void busyWait(uint32_t timeoutMs = 60000);
    uint8_t colorGet(uint8_t color);
    uint16_t _init_width, _init_height;
    int8_t _busyPin;
};

#endif // SEEED_GFX_DRIVER_ED2208_H
